
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/components/HeroSection';
import FeaturedAttractions from '@/components/FeaturedAttractions';
import FoodSection from '@/components/FoodSection';
import CultureSection from '@/components/CultureSection';
import EventsSection from '@/components/EventsSection';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <HeroSection />
      <FeaturedAttractions />
      <FoodSection />
      <CultureSection />
      <EventsSection />
      <Footer />
    </div>
  );
}
