
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-orange-500 mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
              Pune Explore
            </h3>
            <p className="text-gray-400 mb-4">
              Discover the vibrant culture, rich history, and modern attractions of Pune - the Oxford of the East.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-8 h-8 flex items-center justify-center bg-orange-600 hover:bg-orange-700 rounded-full transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-sm"></i>
              </a>
              <a href="#" className="w-8 h-8 flex items-center justify-center bg-orange-600 hover:bg-orange-700 rounded-full transition-colors cursor-pointer">
                <i className="ri-twitter-fill text-sm"></i>
              </a>
              <a href="#" className="w-8 h-8 flex items-center justify-center bg-orange-600 hover:bg-orange-700 rounded-full transition-colors cursor-pointer">
                <i className="ri-instagram-fill text-sm"></i>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Explore</h4>
            <ul className="space-y-2">
              <li><Link href="/attractions" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Tourist Attractions</Link></li>
              <li><Link href="/food" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Food & Dining</Link></li>
              <li><Link href="/culture" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Culture & Heritage</Link></li>
              <li><Link href="/events" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Events & Festivals</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Plan Your Visit</h4>
            <ul className="space-y-2">
              <li><Link href="/plan" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Trip Planning</Link></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Weather</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Transportation</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors cursor-pointer">Hotels</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <div className="space-y-2">
              <p className="text-gray-400 flex items-center">
                <span className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-phone-fill text-sm"></i>
                </span>
                +91 20 1234 5678
              </p>
              <p className="text-gray-400 flex items-center">
                <span className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-mail-fill text-sm"></i>
                </span>
                info@puneexplore.com
              </p>
              <p className="text-gray-400 flex items-center">
                <span className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-map-pin-fill text-sm"></i>
                </span>
                Pune, Maharashtra, India
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Pune Explore. All rights reserved. | Made with ❤️ in Pune
          </p>
        </div>
      </div>
    </footer>
  );
}
