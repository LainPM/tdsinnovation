
'use client';

import Link from 'next/link';

export default function CultureSection() {
  const culturalHighlights = [
    {
      title: "Ganesh Chaturthi",
      description: "Experience the grand celebration of Lord Ganesh with elaborate pandals and processions",
      icon: "ri-star-fill"
    },
    {
      title: "Lavani Dance",
      description: "Traditional Maharashtrian folk dance performed during festivals and celebrations",
      icon: "ri-music-fill"
    },
    {
      title: "Pune Festival",
      description: "Annual cultural extravaganza showcasing art, music, and literature",
      icon: "ri-calendar-event-fill"
    },
    {
      title: "Marathi Theatre",
      description: "Rich theatrical tradition with numerous theaters and performance venues",
      icon: "ri-movie-fill"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-r from-orange-50 to-yellow-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Cultural Heritage</h2>
            <p className="text-xl text-gray-600 mb-8">
              Immerse yourself in Pune's vibrant cultural tapestry, where ancient traditions blend seamlessly with modern expressions of art and creativity.
            </p>
            
            <div className="space-y-6">
              {culturalHighlights.map((item, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-orange-600 text-white rounded-full flex-shrink-0">
                    <i className={`${item.icon} text-lg`}></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8">
              <Link href="/culture" className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
                Explore Culture
              </Link>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Traditional%20Marathi%20cultural%20performance%20in%20Pune%20with%20dancers%20in%20colorful%20costumes%2C%20cultural%20festival%2C%20vibrant%20atmosphere%2C%20traditional%20music%20instruments%2C%20heritage%20celebration%2C%20authentic%20Indian%20culture&width=600&height=400&seq=culture-pune&orientation=landscape"
              alt="Pune Culture"
              className="rounded-lg shadow-lg object-cover object-top w-full h-96"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
