
'use client';

import Link from 'next/link';

export default function FeaturedAttractions() {
  const attractions = [
    {
      id: 1,
      name: "Shaniwar Wada",
      description: "Historic fortified palace and seat of the Peshwa rulers",
      image: "https://readdy.ai/api/search-image?query=Ancient%20Shaniwar%20Wada%20palace%20fortress%20in%20Pune%20with%20traditional%20Marathi%20architecture%2C%20stone%20walls%2C%20historical%20monument%2C%20warm%20lighting%2C%20detailed%20architectural%20features%2C%20Indian%20heritage%20site&width=400&height=300&seq=shaniwar-wada&orientation=landscape",
      category: "Historical"
    },
    {
      id: 2,
      name: "Aga Khan Palace",
      description: "Beautiful palace with Mahatma Gandhi's memorial",
      image: "https://readdy.ai/api/search-image?query=Elegant%20Aga%20Khan%20Palace%20in%20Pune%20with%20Indo-Islamic%20architecture%2C%20beautiful%20gardens%2C%20white%20building%20structure%2C%20peaceful%20atmosphere%2C%20historical%20significance%2C%20detailed%20facade&width=400&height=300&seq=aga-khan-palace&orientation=landscape",
      category: "Memorial"
    },
    {
      id: 3,
      name: "Sinhagad Fort",
      description: "Ancient hill fortress with panoramic valley views",
      image: "https://readdy.ai/api/search-image?query=Majestic%20Sinhagad%20Fort%20on%20hilltop%20near%20Pune%2C%20ancient%20stone%20fortress%2C%20mountain%20landscape%2C%20dramatic%20sky%2C%20historical%20ruins%2C%20panoramic%20view%2C%20adventure%20destination&width=400&height=300&seq=sinhagad-fort&orientation=landscape",
      category: "Adventure"
    },
    {
      id: 4,
      name: "Dagdusheth Halwai Ganpati Temple",
      description: "Famous Ganesh temple with rich cultural heritage",
      image: "https://readdy.ai/api/search-image?query=Beautiful%20Dagdusheth%20Halwai%20Ganpati%20Temple%20in%20Pune%20with%20golden%20decorations%2C%20traditional%20Indian%20temple%20architecture%2C%20devotional%20atmosphere%2C%20ornate%20details%2C%20spiritual%20ambiance&width=400&height=300&seq=ganpati-temple&orientation=landscape",
      category: "Religious"
    },
    {
      id: 5,
      name: "Pune University",
      description: "Prestigious educational institution with beautiful campus",
      image: "https://readdy.ai/api/search-image?query=Beautiful%20Pune%20University%20campus%20with%20colonial%20architecture%2C%20lush%20green%20lawns%2C%20academic%20buildings%2C%20students%20walking%2C%20educational%20atmosphere%2C%20tree-lined%20pathways&width=400&height=300&seq=pune-university&orientation=landscape",
      category: "Educational"
    },
    {
      id: 6,
      name: "Osho Ashram",
      description: "International meditation and spiritual retreat center",
      image: "https://readdy.ai/api/search-image?query=Peaceful%20Osho%20Ashram%20in%20Pune%20with%20modern%20meditation%20halls%2C%20zen%20garden%2C%20minimalist%20architecture%2C%20spiritual%20atmosphere%2C%20natural%20lighting%2C%20tranquil%20environment&width=400&height=300&seq=osho-ashram&orientation=landscape",
      category: "Spiritual"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Attractions</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover the must-visit places that showcase Pune's rich heritage and modern charm
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {attractions.map((attraction) => (
            <div key={attraction.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow group cursor-pointer">
              <div className="relative h-48">
                <img 
                  src={attraction.image} 
                  alt={attraction.name}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 right-3">
                  <span className="bg-orange-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {attraction.category}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{attraction.name}</h3>
                <p className="text-gray-600 mb-4 line-clamp-2">{attraction.description}</p>
                
                <div className="flex items-center justify-between">
                  <Link href={`/attractions/${attraction.id}`} className="text-orange-600 hover:text-orange-700 font-medium cursor-pointer">
                    Learn More
                  </Link>
                  <div className="flex items-center text-gray-500">
                    <span className="w-4 h-4 flex items-center justify-center mr-1">
                      <i className="ri-map-pin-line text-sm"></i>
                    </span>
                    <span className="text-sm">Pune</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/attractions" className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
            View All Attractions
          </Link>
        </div>
      </div>
    </section>
  );
}
