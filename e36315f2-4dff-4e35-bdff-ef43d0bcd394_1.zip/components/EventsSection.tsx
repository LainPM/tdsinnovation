
'use client';

import Link from 'next/link';

export default function EventsSection() {
  const upcomingEvents = [
    {
      date: "Dec 25, 2024",
      title: "Pune International Film Festival",
      location: "Multiple Venues",
      type: "Film Festival",
      description: "Showcasing independent films from around the world"
    },
    {
      date: "Jan 15, 2025",
      title: "Sawai Gandharva Music Festival",
      location: "Shanmukhananda Hall",
      type: "Classical Music",
      description: "Premier classical music festival featuring renowned artists"
    },
    {
      date: "Feb 20, 2025",
      title: "Pune Food Festival",
      location: "Koregaon Park",
      type: "Food Festival",
      description: "Celebration of local and international cuisine"
    },
    {
      date: "Mar 10, 2025",
      title: "Shivaji Jayanti Celebration",
      location: "Shaniwar Wada",
      type: "Cultural Event",
      description: "Commemorating the great Maratha warrior king"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Upcoming Events</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Stay updated with the latest festivals, concerts, and cultural events happening in Pune
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {upcomingEvents.map((event, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 flex items-center justify-center bg-orange-600 text-white rounded-full">
                    <i className="ri-calendar-event-fill text-lg"></i>
                  </div>
                  <div>
                    <p className="text-sm text-orange-600 font-medium">{event.date}</p>
                    <p className="text-sm text-gray-500">{event.type}</p>
                  </div>
                </div>
                <span className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm font-medium">
                  Upcoming
                </span>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{event.title}</h3>
              <p className="text-gray-600 mb-3">{event.description}</p>
              
              <div className="flex items-center text-gray-500">
                <span className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-map-pin-line text-sm"></i>
                </span>
                <span className="text-sm">{event.location}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-lg p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Never Miss an Event</h3>
          <p className="text-orange-100 mb-6 max-w-2xl mx-auto">
            Subscribe to our newsletter to get notified about upcoming festivals, concerts, and cultural events in Pune
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-300"
            />
            <button className="bg-white text-orange-600 px-6 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
              Subscribe
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
