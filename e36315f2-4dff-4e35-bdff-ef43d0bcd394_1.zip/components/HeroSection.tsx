
'use client';

import Link from 'next/link';

export default function HeroSection() {
  return (
    <section 
      className="relative h-screen flex items-center justify-center bg-cover bg-center"
      style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Beautiful%20panoramic%20view%20of%20Pune%20city%20skyline%20during%20golden%20hour%20with%20modern%20buildings%20and%20traditional%20architecture%2C%20vibrant%20orange%20and%20warm%20tones%2C%20clean%20sky%2C%20professional%20photography%20style%2C%20detailed%20urban%20landscape&width=1920&height=1080&seq=pune-hero-bg&orientation=landscape')`
      }}
    >
      <div className="absolute inset-0 bg-black/40"></div>
      
      <div className="relative z-10 text-center text-white px-4 max-w-4xl">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          Discover the Heart of 
          <span className="text-orange-400"> Maharashtra</span>
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-2xl mx-auto">
          Explore Pune's rich culture, historical landmarks, vibrant food scene, and modern attractions in the Oxford of the East
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/attractions" className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
            Explore Attractions
          </Link>
          <Link href="/plan" className="bg-transparent border-2 border-white hover:bg-white hover:text-gray-900 text-white px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
            Plan Your Trip
          </Link>
        </div>
      </div>
    </section>
  );
}
