
'use client';

import Link from 'next/link';

export default function FoodSection() {
  const dishes = [
    {
      name: "Misal Pav",
      description: "Spicy curry with bread rolls - Pune's signature dish",
      image: "https://readdy.ai/api/search-image?query=Delicious%20Misal%20Pav%20dish%20from%20Pune%20with%20spicy%20curry%2C%20bread%20rolls%2C%20onions%2C%20traditional%20Indian%20street%20food%2C%20vibrant%20colors%2C%20authentic%20presentation%2C%20appetizing%20close-up&width=300&height=200&seq=misal-pav&orientation=landscape"
    },
    {
      name: "Bhel Puri",
      description: "Crispy puffed rice snack with chutneys",
      image: "https://readdy.ai/api/search-image?query=Fresh%20Bhel%20Puri%20Indian%20street%20food%20with%20puffed%20rice%2C%20vegetables%2C%20chutneys%2C%20colorful%20presentation%2C%20traditional%20snack%2C%20appetizing%20close-up%2C%20Mumbai%20street%20food%20style&width=300&height=200&seq=bhel-puri&orientation=landscape"
    },
    {
      name: "Vada Pav",
      description: "Mumbai's iconic burger with potato fritter",
      image: "https://readdy.ai/api/search-image?query=Authentic%20Vada%20Pav%20burger%20with%20potato%20fritter%2C%20bread%20bun%2C%20chutneys%2C%20Indian%20street%20food%2C%20golden%20brown%20vada%2C%20traditional%20presentation%2C%20appetizing%20close-up&width=300&height=200&seq=vada-pav&orientation=landscape"
    },
    {
      name: "Puran Poli",
      description: "Sweet flatbread with jaggery and lentil filling",
      image: "https://readdy.ai/api/search-image?query=Traditional%20Puran%20Poli%20sweet%20flatbread%20with%20jaggery%20filling%2C%20ghee%2C%20Indian%20dessert%2C%20golden%20color%2C%20homemade%20appearance%2C%20authentic%20Maharashtrian%20sweet%2C%20appetizing%20presentation&width=300&height=200&seq=puran-poli&orientation=landscape"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Taste of Pune</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Savor the authentic flavors of Pune's vibrant street food and traditional cuisine
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {dishes.map((dish, index) => (
            <div key={index} className="bg-gray-50 rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
              <div className="h-40">
                <img 
                  src={dish.image} 
                  alt={dish.name}
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{dish.name}</h3>
                <p className="text-gray-600 text-sm">{dish.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-orange-50 rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Discover More Culinary Delights</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            From street food stalls to fine dining restaurants, explore Pune's diverse food scene with our comprehensive dining guide
          </p>
          <Link href="/food" className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
            Explore Food Guide
          </Link>
        </div>
      </div>
    </section>
  );
}
